export interface SlideData {
  id: string;
  imageUrl: string;
  originalImageUrl?: string;
  isRotated?: boolean;
  pageNumber: number;
}

export interface CommentData {
  id: string;
  text: string;
  timestamp: number;
}

export interface ReelData {
  id: string;
  slide: SlideData;
  likes: number;
  comments: CommentData[];
  voiceoverUrl?: string | null;
  bgmUrl?: string | null;
  isLikedByMe?: boolean;
}

export interface DeckData {
  id: string;
  name: string;
  createdAt: number;
  reels: ReelData[];
}
