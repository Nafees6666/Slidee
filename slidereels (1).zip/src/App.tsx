import React, { useState, useRef, useEffect } from 'react';
import { get, set } from 'idb-keyval';
import { PdfUploader } from './components/PdfUploader';
import { ReelSlide } from './components/ReelSlide';
import { CommentsModal } from './components/CommentsModal';
import { ReelData, SlideData, DeckData } from './types';
import { ArrowLeft, FolderOpen, Play, Edit2, Trash2, Music, VolumeX, Volume2, Plus } from 'lucide-react';
import { rotateImageBase64 } from './lib/pdf';

export default function App() {
  const [decks, setDecks] = useState<DeckData[]>([]);
  const [activeDeckId, setActiveDeckId] = useState<string | null>(null);
  const [activeReelId, setActiveReelId] = useState<string | null>(null);
  const [isCommentsOpen, setIsCommentsOpen] = useState(false);
  const [activeCommentReelId, setActiveCommentReelId] = useState<string | null>(null);

  // Modal states
  const [deckToDelete, setDeckToDelete] = useState<string | null>(null);
  const [deckToRename, setDeckToRename] = useState<DeckData | null>(null);
  const [renameValue, setRenameValue] = useState("");

  // Global Audio states
  const [globalBgmUrl, setGlobalBgmUrl] = useState<string | null>("https://actions.google.com/sounds/v1/ambiences/spring_day_forest.ogg");
  const [isMuted, setIsMuted] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const globalAudioRef = useRef<HTMLAudioElement | null>(null);
  const globalBgmInputRef = useRef<HTMLInputElement>(null);

  const feedRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    get('slide_decks').then(val => {
      if (val) setDecks(val);
    });
  }, []);

  const saveDecks = (newDecks: DeckData[]) => {
    setDecks(newDecks);
    set('slide_decks', newDecks);
  };

  const handleSlidesExtracted = (slides: SlideData[]) => {
    const newDeck: DeckData = {
      id: crypto.randomUUID(),
      name: `Class Deck ${new Date().toLocaleDateString()}`,
      createdAt: Date.now(),
      reels: slides.map(slide => ({
        id: crypto.randomUUID(),
        slide,
        likes: 0,
        comments: [],
        isLikedByMe: false,
      }))
    };
    const newDecks = [newDeck, ...decks];
    saveDecks(newDecks);
    setActiveDeckId(newDeck.id);
    if (newDeck.reels.length > 0) {
      setActiveReelId(newDeck.reels[0].id);
    }
  };

  const renameDeck = (deckId: string) => {
    const deck = decks.find(d => d.id === deckId);
    if (!deck) return;
    setDeckToRename(deck);
    setRenameValue(deck.name);
  };

  const confirmRename = () => {
    if (deckToRename && renameValue.trim() !== '') {
      const newDecks = decks.map(d => d.id === deckToRename.id ? { ...d, name: renameValue.trim() } : d);
      saveDecks(newDecks);
    }
    setDeckToRename(null);
  };

  const deleteDeck = (deckId: string) => {
    setDeckToDelete(deckId);
  };

  const confirmDelete = () => {
    if (deckToDelete) {
      const newDecks = decks.filter(d => d.id !== deckToDelete);
      saveDecks(newDecks);
    }
    setDeckToDelete(null);
  };

  const handleGlobalBgmUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    setGlobalBgmUrl(url);
    setIsMuted(false);
  };

  const handleLike = (reelId: string) => {
    const newDecks = decks.map(deck => {
      if (deck.id === activeDeckId) {
        return {
          ...deck,
          reels: deck.reels.map(reel => {
            if (reel.id === reelId) {
              return {
                ...reel,
                isLikedByMe: !reel.isLikedByMe,
                likes: reel.isLikedByMe ? reel.likes - 1 : reel.likes + 1
              };
            }
            return reel;
          })
        };
      }
      return deck;
    });
    saveDecks(newDecks);
  };

  const handleAddComment = (reelId: string, text: string) => {
    const newDecks = decks.map(deck => {
      if (deck.id === activeDeckId) {
        return {
          ...deck,
          reels: deck.reels.map(reel => {
            if (reel.id === reelId) {
              return {
                ...reel,
                comments: [...reel.comments, {
                  id: crypto.randomUUID(),
                  text,
                  timestamp: Date.now()
                }]
              };
            }
            return reel;
          })
        };
      }
      return deck;
    });
    saveDecks(newDecks);
  };

  const handleRotate = async (reelId: string) => {
    const deck = decks.find(d => d.id === activeDeckId);
    if (!deck) return;
    const reel = deck.reels.find(r => r.id === reelId);
    if (!reel) return;

    try {
      const isCurrentlyRotated = reel.slide.isRotated;
      let newImageUrl = reel.slide.imageUrl;
      
      if (isCurrentlyRotated && reel.slide.originalImageUrl) {
        newImageUrl = reel.slide.originalImageUrl;
      } else {
        newImageUrl = await rotateImageBase64(reel.slide.originalImageUrl || reel.slide.imageUrl);
      }

      const newDecks = decks.map(d => {
        if (d.id === activeDeckId) {
          return {
            ...d,
            reels: d.reels.map(r => {
              if (r.id === reelId) {
                return {
                  ...r,
                  slide: {
                    ...r.slide,
                    imageUrl: newImageUrl,
                    originalImageUrl: r.slide.originalImageUrl || r.slide.imageUrl,
                    isRotated: !isCurrentlyRotated
                  }
                };
              }
              return r;
            })
          };
        }
        return d;
      });
      saveDecks(newDecks);
    } catch (e) {
      console.error('Failed to rotate image', e);
      alert('Could not rotate image. It may be corrupted.');
    }
  };

  const handleShare = (reelId: string) => {
    const dummyLink = `${window.location.origin}/share/${reelId}`;
    navigator.clipboard.writeText(dummyLink);
    alert(`Link copied to clipboard! (Simulated local share)`);
  };

  // Intersection Observer to track which reel is active in the feed
  useEffect(() => {
    if (!feedRef.current || !activeDeckId) return;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const reelId = entry.target.getAttribute('data-reel-id');
          if (reelId) setActiveReelId(reelId);
        }
      });
    }, {
      root: feedRef.current,
      threshold: 0.6
    });

    const children = feedRef.current.children;
    for (let i = 0; i < children.length; i++) {
      observer.observe(children[i]);
    }

    return () => observer.disconnect();
  }, [activeDeckId, decks]);

  const activeDeck = activeDeckId ? decks.find(d => d.id === activeDeckId) : null;
  const activeCommentReel = activeCommentReelId && activeDeck ? activeDeck.reels.find(r => r.id === activeCommentReelId) : null;

  return (
    <>
      {(!activeDeckId || !activeDeck) ? (
        <div className="h-screen bg-[#F9F9F8] flex flex-col font-sans overflow-hidden">
        <header className="bg-white border-b border-stone-200 px-6 py-4 z-20 shrink-0">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3 text-stone-800 font-bold text-2xl tracking-tight font-display">
              <span className="bg-stone-900 text-stone-50 p-2 rounded-xl shadow-md leading-none font-sans text-sm">SR</span>
              SlideReels
            </div>
          </div>
        </header>
        
        <main className="flex-1 max-w-7xl mx-auto w-full p-6 md:p-8 overflow-y-auto">
          {decks.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center max-w-lg mx-auto pb-20">
              <div className="w-20 h-20 bg-stone-100 rounded-3xl flex items-center justify-center mb-6 border border-stone-200">
                <FolderOpen className="w-10 h-10 text-stone-400" />
              </div>
              <h1 className="text-3xl font-display text-stone-900 mb-4">Your Library is Empty</h1>
              <p className="text-stone-500 text-lg">Upload a PDF using the button in the bottom right to start creating interactive slide reels.</p>
            </div>
          ) : (
            <section className="h-full flex flex-col">
              <h2 className="text-2xl font-display text-stone-900 mb-6 flex items-center gap-3 shrink-0">
                <FolderOpen className="w-6 h-6 text-stone-400" />
                Library
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 pb-24">
                {decks.map(deck => (
                  <div key={deck.id} className="bg-white rounded-2xl shadow-sm border border-stone-200 overflow-hidden hover:shadow-lg transition-all group flex flex-col h-56">
                    <div 
                      className="h-32 bg-stone-100 relative cursor-pointer overflow-hidden border-b border-stone-100 shrink-0"
                      onClick={() => setActiveDeckId(deck.id)}
                    >
                      <img src={deck.reels[0]?.slide.imageUrl} className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-500" alt="Deck thumbnail" />
                      <div className="absolute inset-0 bg-stone-900/10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className="w-10 h-10 bg-white/90 rounded-full flex items-center justify-center backdrop-blur-md shadow-lg transform group-hover:scale-110 transition-transform">
                          <Play className="w-4 h-4 text-stone-900 ml-1" />
                        </div>
                      </div>
                    </div>
                    <div className="p-3 flex items-start justify-between flex-1 bg-white">
                      <div className="overflow-hidden mr-2 flex-1">
                        <h3 className="font-semibold text-stone-900 text-sm truncate font-display" title={deck.name}>{deck.name}</h3>
                        <p className="text-[11px] text-stone-500 mt-0.5 font-medium">{new Date(deck.createdAt).toLocaleDateString()} • {deck.reels.length} Slides</p>
                      </div>
                      <div className="flex items-center flex-col gap-1 shrink-0">
                        <button onClick={() => renameDeck(deck.id)} className="p-1.5 text-stone-400 hover:text-stone-900 rounded-lg hover:bg-stone-50 transition-colors" title="Rename">
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => deleteDeck(deck.id)} className="p-1.5 text-stone-400 hover:text-red-700 rounded-lg hover:bg-red-50 transition-colors" title="Delete">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          <PdfUploader onSlidesExtracted={handleSlidesExtracted} />
        </main>
      </div>
    ) : (
      <div className="flex justify-center bg-black min-h-screen w-full relative h-[100dvh] overflow-hidden font-sans">
      <div className="w-full max-w-md bg-gray-900 h-full relative shadow-2xl flex flex-col">
        
        {globalBgmUrl && (
          <audio 
            ref={globalAudioRef}
            src={globalBgmUrl}
            loop
            muted={isMuted}
            autoPlay
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
          />
        )}

        <div className="absolute top-0 inset-x-0 z-20 flex items-center justify-between p-4 pointer-events-none">
          <button 
            onClick={() => setActiveDeckId(null)}
            className="pointer-events-auto bg-black/40 text-white p-3 rounded-full backdrop-blur-md hover:bg-black/60 transition-transform active:scale-90"
            title="Back to Dashboard"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="font-semibold text-white drop-shadow-md tracking-wide truncate max-w-[200px]">{activeDeck.name}</div>
          
          <div className="flex gap-2 pointer-events-auto">
            <button 
              onClick={() => globalBgmInputRef.current?.click()}
              className="bg-black/40 text-white p-3 rounded-full backdrop-blur-md hover:bg-black/60 transition-transform active:scale-90"
              title="Change Global Music"
            >
              <Plus className="w-5 h-5" />
            </button>
            <button 
              onClick={() => {
                const newMuted = !isMuted;
                setIsMuted(newMuted);
                if (globalAudioRef.current) {
                   if (newMuted) {
                     globalAudioRef.current.pause();
                     setIsPlaying(false);
                   } else {
                     globalAudioRef.current.play().catch(e => console.log('Audio play error:', e));
                     setIsPlaying(true);
                   }
                }
              }}
              className="bg-black/40 text-white p-3 rounded-full backdrop-blur-md hover:bg-black/60 transition-transform active:scale-90"
              title={isMuted ? "Unmute Music" : "Mute Music"}
            >
              {isMuted || !isPlaying ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
            </button>
            <input 
              type="file" 
              ref={globalBgmInputRef}
              className="hidden" 
              accept="audio/*" 
              onChange={handleGlobalBgmUpload}
            />
          </div>
        </div>

        <div 
          ref={feedRef}
          className="flex-1 h-full w-full overflow-y-scroll snap-y snap-mandatory hide-scrollbar pb-[env(safe-area-bottom)]"
        >
          {activeDeck.reels.map(reel => (
            <div key={reel.id} className="w-full h-full snap-start relative" data-reel-id={reel.id}>
              <ReelSlide 
                reel={reel}
                isActive={activeReelId === reel.id}
                onLike={() => handleLike(reel.id)}
                onOpenComments={() => {
                  setActiveCommentReelId(reel.id);
                  setIsCommentsOpen(true);
                }}
                onShare={() => handleShare(reel.id)}
                onRotate={() => handleRotate(reel.id)}
              />
            </div>
          ))}
        </div>
      </div>
      </div>
      )}

      {isCommentsOpen && activeCommentReel && (
        <CommentsModal 
          comments={activeCommentReel.comments}
          onClose={() => {
            setIsCommentsOpen(false);
            setActiveCommentReelId(null);
          }}
          onAddComment={(text) => handleAddComment(activeCommentReel.id, text)}
        />
      )}
      
      <style>{`
        .hide-scrollbar::-webkit-scrollbar { display: none; }
        .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
      
      {/* Rename Modal */}
      {deckToRename && (
        <div className="fixed inset-0 bg-stone-900/40 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
          <div className="bg-white rounded-3xl p-6 md:p-8 max-w-md w-full shadow-2xl animate-in fade-in zoom-in duration-200">
            <h3 className="text-2xl font-display text-stone-900 mb-2">Rename Deck</h3>
            <p className="text-stone-500 mb-6 text-sm">Enter a new name for your slide deck.</p>
            <input 
              type="text" 
              value={renameValue} 
              onChange={(e) => setRenameValue(e.target.value)}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 mb-6 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
              autoFocus
              onKeyDown={(e) => {
                if (e.key === 'Enter') confirmRename();
                if (e.key === 'Escape') setDeckToRename(null);
              }}
            />
            <div className="flex justify-end gap-3">
              <button 
                onClick={() => setDeckToRename(null)}
                className="px-5 py-2.5 rounded-xl text-stone-600 font-medium hover:bg-stone-100 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={confirmRename}
                className="px-5 py-2.5 rounded-xl bg-stone-900 text-white font-medium hover:bg-stone-800 transition-colors"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Modal */}
      {deckToDelete && (
        <div className="fixed inset-0 bg-stone-900/40 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
          <div className="bg-white rounded-3xl p-6 md:p-8 max-w-md w-full shadow-2xl animate-in fade-in zoom-in duration-200">
            <h3 className="text-2xl font-display text-stone-900 mb-2 text-red-600">Delete Deck</h3>
            <p className="text-stone-500 mb-6 text-base">Are you sure you want to delete this deck? This action cannot be undone and all extracted slides will be permanently removed.</p>
            <div className="flex justify-end gap-3">
              <button 
                onClick={() => setDeckToDelete(null)}
                className="px-5 py-2.5 rounded-xl text-stone-600 font-medium hover:bg-stone-100 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={confirmDelete}
                className="px-5 py-2.5 rounded-xl bg-red-600 text-white font-medium hover:bg-red-700 transition-colors"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
