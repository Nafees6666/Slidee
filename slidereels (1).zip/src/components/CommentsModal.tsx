import React, { useState } from 'react';
import { X, Send } from 'lucide-react';
import { CommentData } from '../types';

interface CommentsModalProps {
  comments: CommentData[];
  onClose: () => void;
  onAddComment: (text: string) => void;
}

export function CommentsModal({ comments, onClose, onAddComment }: CommentsModalProps) {
  const [text, setText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    onAddComment(text.trim());
    setText('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm sm:p-4 animate-in fade-in duration-200">
      <div className="w-full h-[70vh] sm:h-auto sm:max-h-[80vh] sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl flex flex-col shadow-2xl animate-in slide-in-from-bottom-full sm:slide-in-from-bottom-10 duration-300">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900">Comments</h2>
          <button 
            onClick={onClose}
            className="p-2 -mr-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Comment List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50/50">
          {comments.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-gray-500">
              <MessageCircleOff />
              <p className="mt-2 text-sm font-medium">No comments yet.</p>
              <p className="text-xs">Be the first to share your thoughts!</p>
            </div>
          ) : (
            comments.map(c => (
              <div key={c.id} className="flex gap-3 bg-white p-3 rounded-2xl shadow-sm border border-gray-100">
                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-500 to-indigo-500 flex-shrink-0" />
                <div>
                  <div className="flex items-baseline gap-2">
                    <span className="font-semibold text-sm text-gray-900">Student</span>
                    <span className="text-xs text-gray-400">
                      {new Date(c.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-sm text-gray-700 mt-0.5 leading-relaxed">{c.text}</p>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Input Area */}
        <div className="p-4 bg-white border-t border-gray-100 sm:rounded-b-3xl pb-safe">
          <form onSubmit={handleSubmit} className="relative flex items-center">
            <input 
              type="text" 
              value={text}
              onChange={e => setText(e.target.value)}
              placeholder="Add a comment..." 
              className="w-full bg-gray-100 border-transparent focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-200 rounded-full py-3 pl-4 pr-12 text-sm transition-all"
            />
            <button 
              type="submit"
              disabled={!text.trim()}
              className="absolute right-2 p-2 bg-blue-500 text-white rounded-full hover:bg-blue-600 disabled:opacity-50 disabled:bg-gray-300 transition-colors"
            >
              <Send className="w-4 h-4 translate-x-[-1px] translate-y-[1px]" />
            </button>
          </form>
        </div>

      </div>
    </div>
  );
}

function MessageCircleOff() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="opacity-20">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
    </svg>
  );
}
