import React, { useState, useRef, MouseEvent, TouchEvent } from 'react';
import { cn } from '../lib/utils';

interface MagnifierProps {
  src: string;
  isActive: boolean;
  className?: string;
  zoomLevel?: number;
  onDoubleClick?: () => void;
}

export function Magnifier({ src, isActive, className, zoomLevel = 2.5, onDoubleClick }: MagnifierProps) {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [showMagnifier, setShowMagnifier] = useState(false);
  const [cursorPosition, setCursorPosition] = useState({ x: 0, y: 0 });
  const imgRef = useRef<HTMLImageElement>(null);

  const handlePointerMove = (e: MouseEvent<HTMLDivElement> | TouchEvent<HTMLDivElement>) => {
    if (!isActive || !imgRef.current) return;
    
    let clientX, clientY;
    if ('touches' in e) {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
    } else {
        clientX = e.clientX;
        clientY = e.clientY;
    }

    const { left, top, width, height } = imgRef.current.getBoundingClientRect();
    
    const x = clientX - left;
    const y = clientY - top;

    if (x < 0 || y < 0 || x > width || y > height) {
      setShowMagnifier(false);
      return;
    }

    const xPercent = (x / width) * 100;
    const yPercent = (y / height) * 100;

    setPosition({ x: xPercent, y: yPercent });
    setCursorPosition({ x, y });
    setShowMagnifier(true);
  };

  const handlePointerLeave = () => {
    setShowMagnifier(false);
  };

  return (
    <div 
      className={cn("relative w-full h-full flex items-center justify-center overflow-hidden", className, isActive && "touch-none")}
      onMouseMove={handlePointerMove}
      onMouseLeave={handlePointerLeave}
      onTouchMove={handlePointerMove}
      onTouchEnd={handlePointerLeave}
      onTouchCancel={handlePointerLeave}
      onDoubleClick={onDoubleClick}
    >
      <img
        ref={imgRef}
        src={src}
        alt="Slide"
        className="max-w-full max-h-full object-contain select-none"
        draggable={false}
      />

      {isActive && showMagnifier && (
        <div
          className="absolute pointer-events-none border-[3px] border-white/80 rounded-3xl shadow-2xl overflow-hidden bg-white transition-transform"
          style={{
            left: `${cursorPosition.x - 125}px`,
            top: `${cursorPosition.y < 285 ? cursorPosition.y - 125 + 180 : cursorPosition.y - 125 - 180}px`,
            width: '250px',
            height: '250px',
            backgroundImage: `url(${src})`,
            backgroundRepeat: 'no-repeat',
            backgroundSize: `${imgRef.current?.width ? imgRef.current.width * zoomLevel : 100 * zoomLevel}px ${imgRef.current?.height ? imgRef.current.height * zoomLevel : 100 * zoomLevel}px`,
            backgroundPosition: `${position.x}% ${position.y}%`,
            zIndex: 50,
          }}
        >
          <div className="absolute inset-0 shadow-[inset_0_0_15px_rgba(0,0,0,0.2)] rounded-3xl mix-blend-overlay"></div>
        </div>
      )}
    </div>
  );
}
