import React, { useState, useRef, useEffect } from 'react';
import { Heart, MessageCircle, Share2, Search, RotateCw } from 'lucide-react';
import { ReelData } from '../types';
import { Magnifier } from './Magnifier';
import { cn } from '../lib/utils';

interface ReelSlideProps {
  reel: ReelData;
  isActive: boolean;
  onLike: () => void;
  onOpenComments: () => void;
  onShare: () => void;
  onRotate: () => void;
}

export function ReelSlide({ reel, isActive, onLike, onOpenComments, onShare, onRotate }: ReelSlideProps) {
  const [isMagnifying, setIsMagnifying] = useState(false);
  const [showBigHeart, setShowBigHeart] = useState(false);
  
  const [isHolding, setIsHolding] = useState(false);
  const holdTimerRef = useRef<NodeJS.Timeout | null>(null);

  const handlePointerDown = () => {
    holdTimerRef.current = setTimeout(() => {
      setIsHolding(true);
    }, 200);
  };

  const handlePointerUpOrLeave = () => {
    if (holdTimerRef.current) {
      clearTimeout(holdTimerRef.current);
    }
    setIsHolding(false);
  };

  useEffect(() => {
    if (!isActive) {
      setIsMagnifying(false);
    }
  }, [isActive]);

  const handleDoubleClick = () => {
    if (!reel.isLikedByMe) {
      onLike();
    }
    setShowBigHeart(true);
    setTimeout(() => setShowBigHeart(false), 1000);
  };

  return (
    <div className="relative w-full h-full bg-black flex items-center justify-center overflow-hidden snap-start">
      {/* Main content: The Slide */}
      <div 
        className="w-full h-full max-h-[85vh] relative flex items-center justify-center cursor-pointer select-none"
        onPointerDown={handlePointerDown}
        onPointerUp={handlePointerUpOrLeave}
        onPointerLeave={handlePointerUpOrLeave}
        onPointerCancel={handlePointerUpOrLeave}
        onContextMenu={(e) => { e.preventDefault(); }}
      >
        <Magnifier 
          src={reel.slide.imageUrl} 
          isActive={isMagnifying} 
          className="w-full h-full"
          onDoubleClick={handleDoubleClick}
        />
      </div>

      {/* Big Heart Overlay */}
      {showBigHeart && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-50">
          <Heart className="w-32 h-32 text-red-500 fill-red-500 drop-shadow-2xl animate-heart-burst" />
        </div>
      )}

      {/* Overlays */}
      <div className={cn("absolute inset-0 pointer-events-none bg-gradient-to-b from-black/30 via-transparent to-black/60 transition-opacity duration-300", isHolding ? "opacity-0" : "opacity-100")} />

      {/* Top Bar Overlay */}
      <div className={cn("absolute top-0 inset-x-0 p-4 flex justify-between items-start pointer-events-auto z-10 pt-16 transition-opacity duration-300", isHolding ? "opacity-0" : "opacity-100")}>
        <div className="bg-black/40 backdrop-blur-md text-white px-3 py-1.5 rounded-full text-sm font-medium">
          Slide {reel.slide.pageNumber}
        </div>
        
        <div className="flex flex-col gap-3">
          <button 
            onClick={onRotate}
            className="flex flex-col items-center justify-center w-14 h-14 rounded-2xl bg-black/40 text-white/80 hover:text-white hover:bg-black/60 transition-all backdrop-blur-md active:scale-95 shadow-lg"
          >
            <RotateCw className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-bold tracking-wider leading-none">ROTATE</span>
          </button>
          <button 
            onClick={() => setIsMagnifying(!isMagnifying)}
            className={cn(
              "flex flex-col items-center justify-center w-14 h-14 rounded-2xl transition-all backdrop-blur-md active:scale-95 shadow-lg",
              isMagnifying ? "bg-blue-600 text-white" : "bg-black/40 text-white/80 hover:text-white hover:bg-black/60"
            )}
          >
            <Search className="w-5 h-5 mb-1" />
            <span className="text-[10px] font-bold tracking-wider leading-none">MAGNIFY</span>
          </button>
        </div>
      </div>

      {/* Right Sidebar Overlay */}
      <div className={cn("absolute right-4 bottom-28 flex flex-col items-center space-y-6 pointer-events-auto z-10 transition-opacity duration-300", isHolding ? "opacity-0" : "opacity-100")}>
        <div className="flex flex-col items-center opacity-60 hover:opacity-100 transition-opacity">
          <button 
            onClick={onLike}
            className="p-3 bg-black/40 hover:bg-black/60 backdrop-blur-md rounded-full transition-transform active:scale-90"
          >
            <Heart className={cn("w-7 h-7", reel.isLikedByMe ? "fill-red-500 text-red-500" : "text-white")} />
          </button>
          <span className="text-white text-xs font-semibold mt-1 drop-shadow-md">{reel.likes}</span>
        </div>

        <div className="flex flex-col items-center opacity-60 hover:opacity-100 transition-opacity">
          <button 
            onClick={onOpenComments}
            className="p-3 bg-black/40 hover:bg-black/60 backdrop-blur-md rounded-full transition-transform active:scale-90"
          >
            <MessageCircle className="w-7 h-7 text-white" />
          </button>
          <span className="text-white text-xs font-semibold mt-1 drop-shadow-md">{reel.comments.length}</span>
        </div>

        <button 
          onClick={onShare}
          className="p-3 bg-black/40 hover:bg-black/60 backdrop-blur-md rounded-full transition-transform active:scale-90 opacity-60 hover:opacity-100"
          title="Share Slide"
        >
          <Share2 className="w-7 h-7 text-white" />
        </button>
      </div>
    </div>
  );
}
