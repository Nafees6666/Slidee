import React, { useState } from 'react';
import { extractSlidesFromPdf } from '../lib/pdf';
import { Loader2, Plus } from 'lucide-react';
import { SlideData } from '../types';

interface PdfUploaderProps {
  onSlidesExtracted: (slides: SlideData[]) => void;
}

export function PdfUploader({ onSlidesExtracted }: PdfUploaderProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (file.type !== 'application/pdf') {
      setError('Please upload a valid PDF file.');
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      const imageUrls = await extractSlidesFromPdf(file);
      const slides: SlideData[] = imageUrls.map((url, index) => ({
        id: crypto.randomUUID(),
        imageUrl: url,
        pageNumber: index + 1
      }));
      onSlidesExtracted(slides);
    } catch (err) {
      console.error(err);
      setError('Failed to extract slides from PDF. Ensure it is a valid PDF and not password protected.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <>
      <label className="fixed bottom-8 right-8 z-50 flex items-center justify-center w-16 h-16 bg-stone-900 hover:bg-stone-800 text-white rounded-full shadow-2xl cursor-pointer transition-transform hover:scale-105 group">
        {isProcessing ? (
          <Loader2 className="w-6 h-6 animate-spin" />
        ) : (
          <Plus className="w-8 h-8" />
        )}
        <input 
          type="file" 
          className="hidden" 
          accept="application/pdf"
          onChange={handleFileChange}
          disabled={isProcessing}
        />
        {/* Tooltip */}
        <span className="absolute right-full mr-4 bg-stone-800 text-white text-sm px-3 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
          {isProcessing ? "Processing..." : "Upload PDF"}
        </span>
      </label>
      
      {error && (
        <div className="fixed bottom-28 right-8 z-50 p-4 text-sm font-medium text-red-700 bg-red-50 border border-red-100 rounded-xl shadow-lg">
          {error}
        </div>
      )}
    </>
  );
}
